const expect = require('chai').expect();

describe('this is a practice test', ()=>{
    it('should return true I mean hell it\'s an example', ()=>{
        return true;
    });
})

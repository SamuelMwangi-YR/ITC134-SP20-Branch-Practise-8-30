LINUX Shell Scripting Resource: For the next few assignments we’ll work on a whole class group project to build a LINUX bash scripting command line web resource.  The students have self identified as roles of programmer, content manager and web developer and were  broken into small groups.  Each group identified a topic, for example one group is taking on regular expressions and grep and another group might be focusing on cron.  The idea is to create a single page or pages to give a fundamental understanding of the topic, insert code snippets in stylized HTML <i>pre</i> tags on the page and link to an example program designed to illustrate the topic.


Benefits: Doing this work will allow to dig deeper as individuals into topics within the UNIX/LINUX scripting world.  It will stand as a resource to which you contributed, going forward as it will be available on the web.   Creating such a resource allows us to deepen our knowledge on this subject, work together as a larger team, invoke some scrum group processes and add to our github repos and resume.


Adding some text to test Slack integration
